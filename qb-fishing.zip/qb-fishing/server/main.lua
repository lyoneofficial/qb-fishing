local QBCore

TriggerEvent('QBCore:GetObject', function(obj) QBCore = obj end)
    QBCore = obj
end)

RegisterNetEvent("zFishing:startFishing")
AddEventHandler("zFishing:startFishing", function(fishingZoneId)
    local _src = source
    local xPlayer = QBCore.Functions.GetPlayer(src)(_src)
    local haveFishingRod = (xPlayer.Functions.GetItemByName(Config.fishingRod).count >= 1)
    if not haveFishingRod then
        TriggerClientEvent("zFishing:setFishingState", _src, false, "~r~Vous n'avez pas de canne à pêche")
        return
    end
    TriggerClientEvent("zFishing:startFishing", _src, fishingZoneId)
    Wait(1000)
    SetTimeout(math.random(1, 20000), function()
        xPlayer = QBCore.Functions.GetPlayer(_src)
        if not xPlayer then return end
        local reward = Config.availableFish[math.random(#Config.availableFish)]
        local rewardCount = math.random(3)
        xPlayer.Functions.AddItem(reward, rewardCount)
        TriggerClientEvent("zFishing:stopFishing", _src, "~g~Vous avez pêché ~y~"..rewardCount.." ~y~"..ESX.GetItemLabel(reward).." ~g~!")
    end)
end)

RegisterNetEvent("zFishing:sellfishs")
AddEventHandler("zFishing:sellfishs", function()
    local _src = source
    local xPlayer = QBCore.Functions.GetPlayer(_src)
    local total = 0
    for k,v in pairs(Config.availableFish) do
        local count = xPlayer.Functions.GetItemByName(v).count
        if count > 0 then
            xPlayer.Functions.RemoveItem(v, count)
            total = total + (Config.vendor.fishResell[v:lower()]*count)
        end
    end
    if total <= 0 then
        TriggerClientEvent("QBCore:Notify", _src, "~r~Vous n'avez rien vendu !")
        return
    end
    TriggerClientEvent("QBCore:Notify", _src, "~g~Vous avez vendu tous vos poissons pour "..total.."$")
    xPlayer.Functions.AddMoney(total)
end)