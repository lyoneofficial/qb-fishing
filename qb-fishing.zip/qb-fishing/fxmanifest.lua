fx_version "adamant"
game "gta5"

shared_scripts {
    "shared/*.lua"
}

client_scripts {
    "client/*.lua",
}

server_scripts {
    "server/*.lua",
}