# qb-fishing
Fivem QBCore fishing system for RolePlay servers
